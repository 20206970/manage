前后端分离的图书管理系统项目

后端使用Java+SpringBoot+MyBatis+MySQL

前端使用Vue+Axios+Element UI

前端运行：
1.   在项目目录下，输入命令`npm install`安装环境
2.   输入命令`npm run dev`运行程序

更多项目源码搜索哆啦A梦软件开发







