<template>
  <div class="app-container">
<!--    &lt;!&ndash; 顶部功能 &ndash;&gt;-->
<!--    <div class="filter-container" style="margin-bottom: 15px">-->
<!--      &lt;!&ndash; 书名输入 &ndash;&gt;-->
<!--      <el-input v-model="queryParam.userName" placeholder="用户名" style="width: 200px;" class="filter-item" @keyup.enter.native="handleFilter" />-->
<!--      &lt;!&ndash; 一些按钮 &ndash;&gt;-->
<!--      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">-->
<!--        搜索-->
<!--      </el-button>-->
<!--    </div>-->
    <!--数据表格-->
    <el-table
        ref="multipleTable"
        :data="tableData"
        border
        style="width: 100%">
      <el-table-column
          fixed
          type="selection"
      </el-table-column>
      <el-table-column
          fixed
          prop="bookid"
          label="序号"
      </el-table-column>
      <el-table-column
          prop="userName"
          label="用户名"
      >
      </el-table-column>
      <el-table-column
          prop="maxborrow"
          label="可借图书数量"
         >
      </el-table-column>
      <el-table-column
          prop="hasborrow"
          label="已借图书数量">
      </el-table-column>
    </el-table>
    <!--分页条-->
    <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="queryParam.page"
        :page-sizes="[5, 10, 20, 50]"
        :page-size="queryParam.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="recordTotal"
        style="margin-top: 15px">
    </el-pagination>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import permission from '@/directive/permission/index.js' // 权限判断指令
import waves from '@/directive/waves' // waves directive
import { getInfo } from '@/api/reader'

export default {
  name: 'Reader',
  directives: { waves, permission },
  // 创建后
  created() {
    // 从服务器获取数据表格第一页的信息
    getInfo(this.queryParam).then(res => {
      console.log(res)
      this.tableData = res.data
      this.recordTotal = res.count
    })
  },
  mounted() {
    if (this.roleIsAdmin === false) {
      this.queryParam.limit = 5
      this.handleSizeChange(this.queryParam.limit)
    }
  },
  methods: {
    // 分页大小改变监听
    handleSizeChange(curSize) {
      const params = this.queryParam
      params.limit = curSize
      queryBookInfosByPage(params).then(res => {
            console.log('分页数据获取成功',res)
            this.tableData = res.data
            this.recordTotal = res.count
      })
    },

    // 点击分页监听方法
    handleCurrentChange(curPage) {
      const params = this.queryParam
      params.page = curPage
      queryBookInfosByPage(params).then(res => {
            console.log('分页数据获取成功',res)
            this.tableData = res.data
            this.recordTotal = res.count
      })
    },

    // 搜索图书
    handleFilter() {
      this.queryParam.page = 1
      queryBookInfosByPage(this.queryParam).then(res => {
        if(res.code === 0) {
          this.tableData = res.data
          this.recordTotal = res.count
        }
      })
    }
  },
  data() {
    return {
      // 表格数据
      tableData: [],
      // 记录总数
      recordTotal: 0,
      // 图书类型数据
      typeData: [],
      // 用户数据
      userData: [],
      // 查询参数
      queryParam: {
        page: 1,
        limit: 10,
        userName:null
        // bookname: null,
        // bookauthor: null,
        // booktypeid: null
      },
      // 对话框表单显示
      dialogFormVisible: false,
      dialogFormVisible2: false,
      // 表单类型（添加数据:0,修改数据:1）
      formType: 0,
      // 表单数据
      form: {
        bookid: null,
        bookname: '水浒传',
        bookauthor: '1',
        bookprice: '2022-03-05',
        booktypeid: '2022-04-05',
        bookdesc: '',
        isborrowed: 0,
        bookimg: ''
      },
      form2: {
        userid: 1,
        bookid: 1
      },
      rules: {
        bookname: [
          { required: true, message: '请输入图书名称', trigger: 'blur' }
        ],
        bookauthor: [
          { required: true, message: '请输入作者', trigger: 'blur' }
        ],
        bookprice: [
          { required: true, message: '请输入价格', trigger: 'blur' }
        ],
        booktypeid: [
          { required: true, message: '请选择类型', trigger: 'blur' }
        ],
        bookdesc: [
          { required: true, message: '请输入描述', trigger: 'blur' }
        ],
        isborrowed: [
          { required: true, message: '请选择状态', trigger: 'blur' }
        ]
      },
    }
  },
  computed: {
    // 获得user信息
    ...mapGetters(['id','name','roles']),
    // 通过表单类型计算表单标题
    formTitle() {
      return this.formType === 0 ? '添加记录' : '修改记录'
    },
    roleIsAdmin() {
      if(this.roles[0] === 'admin') return true
      else return false
    }
  }
}

</script>

<style scoped>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 150px;
    height: 200px;
    display: block;
  }
</style>
