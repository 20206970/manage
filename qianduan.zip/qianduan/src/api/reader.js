import request from '@/utils/request'

// 获取用户信息
export function getInfo(params) {
  return request({
    url: '/userBorrow/queryBookInfosByPage',
    method: 'get',
    params
  })
}

